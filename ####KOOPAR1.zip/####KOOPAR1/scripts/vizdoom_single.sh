#!/usr/bin/env bash
# 🔥 Flames Co. GameGAN - Intel Arc 140V Single GPU Training Script
# Optimized for Intel Core Ultra 7 with Arc 140V GPU

echo "🔥 Flames Co. GameGAN - Intel Arc 140V Single GPU Training Starting..."
echo "Optimizing for Intel Core Ultra 7 with Arc 140V GPU..."

# Set Intel XPU optimizations for Arc 140V single GPU
export IPEX_XPU_ONEDNN_LAYOUT=1
export IPEX_XPU_ONEDNN_GRAPH=1
export IPEX_XPU_AUTO_KERNEL_SELECTION=1
export IPEX_XPU_POOL_STRATEGY=1
export KMP_BLOCKTIME=1
export KMP_SETTINGS=1
export KMP_AFFINITY="granularity=fine,verbose,compact,1,0"
export OMP_NUM_THREADS=16
export INTEL_DEVICE_VISIBLE=0

# Intel Arc 140V memory optimization for single GPU
export IPEX_XPU_MEMORY_POOL=1
export IPEX_XPU_MEMORY_FRACTION=0.95

echo "Intel XPU Single GPU Environment Configured ✅"
echo "Starting Flames Co. GameGAN Single GPU Training..."

python main_parallel.py \
 --data vizdoom:./data/vizdoom \
 --log_dir ./results/flames_co_vizdoom_single/ \
 --num_steps 32 \
 --warm_up 16 \
 --warmup_decay_epoch 100 \
 --bs 12 \
 --num_components 1 \
 --fixed_v_dim 8 \
 --att_dim 8 \
 --fine_mask \
 --config_temporal 24 \
 --save_epoch 20 \
 --num_gpu 1 \
 --gpu 0 \
 --nfilterG 32 \
 --seed 42069 \
 --img_size 64 \
 --end_bias 0.5 \
 --intel_optimization_level O2 \
 --use_xpu_amp \
 --enable_graph_optimization \
 --intel_memory_pool \
 --xpu_backend level_zero

echo "🔥 Flames Co. GameGAN Single GPU Training Complete! Check ./results/flames_co_vizdoom_single/ for outputs"
echo "Powered by Intel Core Ultra 7 with Arc 140V GPU 🚀"
