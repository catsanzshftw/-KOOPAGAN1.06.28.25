"""
Flames Co. GameGAN - Intel Arc 140V Optimized Device Utilities
Copyright (C) 2024 Flames Co. AI Research Division

Optimized for Intel Core Ultra 7 with Arc 140V GPU using Intel Extension for PyTorch
"""
import torch
import os
import warnings
from typing import Optional, Union, Any

# Try to import Intel Extension for PyTorch with error handling
try:
    import intel_extension_for_pytorch as ipex  # noqa: F401
    IPEX_AVAILABLE = True
except ImportError:
    warnings.warn("Intel Extension for PyTorch not available. Using standard PyTorch.")
    IPEX_AVAILABLE = False
except Exception as e:
    warnings.warn(f"Intel Extension for PyTorch error: {e}. Using standard PyTorch.")
    IPEX_AVAILABLE = False

# Intel XPU device configuration
INTEL_XPU_DEVICE = 'xpu'
INTEL_CPU_DEVICE = 'cpu'

class IntelDeviceManager:
    """Manages Intel XPU/NPU devices for optimal performance on Intel Core Ultra 7 with Arc 140V"""
    
    def __init__(self):
        self.ipex_available = self._check_ipex_availability()
        self.xpu_available = self._check_xpu_availability()
        self.device = self._detect_best_device()
        self.optimization_level = 'O1'  # Default optimization level
        
    def _check_ipex_availability(self) -> bool:
        """Check if Intel Extension for PyTorch is available"""
        try:
            return IPEX_AVAILABLE
        except ImportError:
            warnings.warn("Intel Extension for PyTorch not available. Using standard PyTorch.")
            return False
        except Exception as e:
            warnings.warn(f"Intel Extension for PyTorch error: {e}. Using standard PyTorch.")
            return False
        
    def _detect_best_device(self) -> str:
        """Detect the best available Intel device"""
        try:
            # Try to import IPEX first
            if self._check_ipex_availability():
                if hasattr(torch, 'xpu') and torch.xpu.is_available():
                    return INTEL_XPU_DEVICE
        except Exception as e:
            warnings.warn(f"Intel XPU detection failed: {e}")
        
        # Fallback to CPU with Intel optimizations
        return INTEL_CPU_DEVICE
    
    def _check_xpu_availability(self) -> bool:
        """Check if Intel XPU is available and properly configured"""
        if not self.ipex_available:
            return False
            
        try:
            return hasattr(torch, 'xpu') and torch.xpu.is_available() and torch.xpu.device_count() > 0
        except Exception as e:
            warnings.warn(f"Intel XPU check failed: {e}")
            return False
    
    def get_device(self, device_id: Optional[int] = None) -> torch.device:
        """Get the appropriate torch device"""
        if self.xpu_available and device_id is not None:
            return torch.device(f'{INTEL_XPU_DEVICE}:{device_id}')
        elif self.xpu_available:
            return torch.device(INTEL_XPU_DEVICE)
        else:
            return torch.device(INTEL_CPU_DEVICE)
    
    def to_device(self, tensor_or_model: Union[torch.Tensor, torch.nn.Module], 
                  device_id: Optional[int] = None) -> Union[torch.Tensor, torch.nn.Module]:
        """Move tensor or model to the appropriate Intel device"""
        device = self.get_device(device_id)
        try:
            return tensor_or_model.to(device)
        except Exception as e:
            warnings.warn(f"Failed to move to {device}: {e}. Using CPU.")
            return tensor_or_model.to('cpu')
    
    def optimize_model(self, model: torch.nn.Module, 
                      dtype: torch.dtype = torch.float32,  # Changed from float16 to float32 for compatibility
                      device_id: Optional[int] = None) -> torch.nn.Module:
        """Optimize model for Intel XPU/NPU with IPEX optimizations"""
        device = self.get_device(device_id)
        
        # Move model to device first
        try:
            model = model.to(device)
        except Exception as e:
            warnings.warn(f"Failed to move model to {device}: {e}. Using CPU.")
            model = model.to('cpu')
            device = torch.device('cpu')
        
        # Apply Intel Extension for PyTorch optimizations
        if self.ipex_available:
            try:
                if self.xpu_available and device.type == 'xpu':
                    # XPU-specific optimizations for Arc 140V
                    model = ipex.optimize(
                        model, 
                        dtype=dtype, 
                        device=device,
                        level=self.optimization_level,
                        conv_bn_folding=True,
                        linear_bn_folding=True,
                        weights_prepack=True
                    )
                else:
                    # CPU optimizations with Intel MKL-DNN
                    model = ipex.optimize(
                        model,
                        dtype=dtype,
                        level=self.optimization_level,
                        conv_bn_folding=True,
                        linear_bn_folding=True,
                        weights_prepack=True
                    )
            except Exception as e:
                warnings.warn(f"IPEX optimization failed: {e}. Using standard PyTorch.")
        
        return model
    
    def optimize_memory(self):
        """Optimize memory usage for Intel devices"""
        if self.xpu_available:
            try:
                torch.xpu.empty_cache()
                # Enable memory pool for better allocation
                torch.xpu.set_sync_debug_mode(0)
            except Exception as e:
                warnings.warn(f"XPU memory optimization failed: {e}")
        else:
            # CPU memory optimizations
            try:
                torch.set_num_threads(os.cpu_count())
            except Exception as e:
                warnings.warn(f"CPU optimization failed: {e}")
    
    def enable_mixed_precision(self) -> bool:
        """Enable mixed precision training for Intel devices"""
        return self.xpu_available or True  # CPU also supports mixed precision
    
    def get_autocast_context(self, device_type: Optional[str] = None):
        """Get the appropriate autocast context for mixed precision"""
        if device_type is None:
            device_type = self.device
            
        try:
            if device_type == INTEL_XPU_DEVICE and self.xpu_available:
                return torch.xpu.amp.autocast()
            else:
                return torch.cpu.amp.autocast()
        except Exception as e:
            warnings.warn(f"Autocast context failed: {e}. Using no-op context.")
            # Return a no-op context manager
            from contextlib import nullcontext
            return nullcontext()
    
    def synchronize(self):
        """Synchronize device operations"""
        if self.xpu_available:
            try:
                torch.xpu.synchronize()
            except Exception as e:
                warnings.warn(f"XPU synchronization failed: {e}")

# Global device manager instance
device_manager = IntelDeviceManager()

def get_intel_device(device_id: Optional[int] = None) -> torch.device:
    """Get Intel device (XPU or CPU)"""
    return device_manager.get_device(device_id)

def to_intel_device(tensor_or_model: Union[torch.Tensor, torch.nn.Module], 
                   device_id: Optional[int] = None) -> Union[torch.Tensor, torch.nn.Module]:
    """Move to Intel device"""
    return device_manager.to_device(tensor_or_model, device_id)

def optimize_for_intel(model: torch.nn.Module, 
                      dtype: torch.dtype = torch.float32,
                      device_id: Optional[int] = None) -> torch.nn.Module:
    """Optimize model for Intel hardware"""
    return device_manager.optimize_model(model, dtype, device_id)

def check_gpu(gpu_id: Optional[int], *args) -> Any:
    """
    Intel XPU-compatible version of the original check_gpu function
    Automatically handles device placement for Intel Arc 140V GPU
    """
    device = device_manager.get_device(gpu_id)
    
    if len(args) == 0:
        return []
    
    if isinstance(args[0], dict):
        d = args[0]
        var_dict = {}
        for key in d:
            try:
                if isinstance(d[key], torch.Tensor):
                    var_dict[key] = d[key].to(device)
                else:
                    var_dict[key] = torch.tensor(d[key]).to(device)
            except Exception as e:
                warnings.warn(f"Failed to move tensor to device: {e}")
                var_dict[key] = d[key] if isinstance(d[key], torch.Tensor) else torch.tensor(d[key])
        
        if len(args) > 1:
            return [var_dict] + check_gpu(gpu_id, *args[1:])
        else:
            return [var_dict]
    
    if isinstance(args[0], list):
        result = []
        for a in args[0]:
            try:
                if isinstance(a, torch.Tensor):
                    result.append(a.to(device))
                else:
                    result.append(torch.tensor(a).to(device))
            except Exception as e:
                warnings.warn(f"Failed to move tensor to device: {e}")
                result.append(a if isinstance(a, torch.Tensor) else torch.tensor(a))
        return result
    
    # Multiple arguments
    if len(args) > 1:
        result = []
        for a in args:
            try:
                if isinstance(a, torch.Tensor):
                    result.append(a.to(device))
                else:
                    result.append(torch.tensor(a).to(device))
            except Exception as e:
                warnings.warn(f"Failed to move tensor to device: {e}")
                result.append(a if isinstance(a, torch.Tensor) else torch.tensor(a))
        return result
    else:
        try:
            if isinstance(args[0], torch.Tensor):
                return args[0].to(device)
            else:
                return torch.tensor(args[0]).to(device)
        except Exception as e:
            warnings.warn(f"Failed to move tensor to device: {e}")
            return args[0] if isinstance(args[0], torch.Tensor) else torch.tensor(args[0])

def empty_cache():
    """Empty device cache"""
    device_manager.optimize_memory()

def set_device(device_id: int):
    """Set active device"""
    if device_manager.xpu_available:
        try:
            torch.xpu.set_device(device_id)
        except Exception as e:
            warnings.warn(f"Failed to set XPU device: {e}")

def synchronize():
    """Synchronize device"""
    device_manager.synchronize()

# Intel-specific optimizations for Core Ultra 7 with Arc 140V
def configure_intel_optimizations():
    """Configure Intel-specific optimizations"""
    # Enable Intel MKL optimizations
    try:
        torch.set_num_threads(os.cpu_count())
    except Exception as e:
        warnings.warn(f"Failed to set thread count: {e}")
    
    # Enable Intel Extension for PyTorch optimizations
    try:
        # Enable automatic mixed precision for better performance
        if device_manager.xpu_available:
            # XPU-specific settings for Arc 140V
            os.environ['IPEX_XPU_ONEDNN_LAYOUT'] = '1'
            os.environ['IPEX_XPU_ONEDNN_GRAPH'] = '1'
        
        # CPU optimizations
        os.environ['KMP_BLOCKTIME'] = '1'
        os.environ['KMP_SETTINGS'] = '1'
        os.environ['KMP_AFFINITY'] = 'granularity=fine,verbose,compact,1,0'
        os.environ['OMP_NUM_THREADS'] = str(os.cpu_count())
        
    except Exception as e:
        warnings.warn(f"Could not configure Intel optimizations: {e}")

# Initialize optimizations
configure_intel_optimizations() 