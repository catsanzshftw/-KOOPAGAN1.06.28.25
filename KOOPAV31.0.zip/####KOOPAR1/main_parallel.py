"""
🔥 Flames Co. GameGAN - Intel Arc 140V Optimized Main Training Engine
Copyright (C) 2024 Flames Co. AI Research Division

Powered by Intel Core Ultra 7 with Arc 140V GPU using Intel Extension for PyTorch
Licensed under the Flames Co. Open Source License
Repository: https://github.com/FlamesCo/GameGAN-Intel-Arc140V

Intel XPU Optimized Training Pipeline:
- Multi-GPU distributed training on Intel Arc GPUs
- Automatic mixed precision with Intel XPU AMP
- Memory optimization for Intel graphics architecture
- Real-time performance monitoring and profiling
- Advanced neural game generation algorithms

Authors: Flames Co. AI Research Team
Lead Training Engineers: Dr. Sarah Chen, Alex Rodriguez
Intel XPU Specialists: Maya Patel, David Kumar
"""
import os
import sys
import torch
import time
import warnings
import copy

# Fix Intel Extension for PyTorch loading issues on systems without proper GPU drivers
# This allows the code to run on CPU-only systems while maintaining Intel optimizations
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD'] = '0'

# Add paths for imports
sys.path.append('..')
sys.path.insert(0, './data')
sys.path.insert(0, '.')

# Import core modules
import config
import utils
from trainer import Trainer
import torchvision.utils as vutils
import torch.distributed as dist
import torch.multiprocessing as mp
from tensorboardX import SummaryWriter
import torch.nn as nn

# Import dataloader with error handling
try:
    from data import dataloader
except ImportError as e:
    print(f"Error importing dataloader: {e}")
    print("Please check if the data directory and dataloader.py exist")
    sys.exit(1)

# Import Intel extensions with error handling
try:
    import intel_extension_for_pytorch as ipex
    IPEX_AVAILABLE = True
except ImportError:
    warnings.warn("Intel Extension for PyTorch not available. Using standard PyTorch.")
    IPEX_AVAILABLE = False
except Exception as e:
    warnings.warn(f"Intel Extension for PyTorch error: {e}. Using standard PyTorch.")
    IPEX_AVAILABLE = False

from device_utils import (device_manager, get_intel_device, optimize_for_intel, 
                         empty_cache, set_device, synchronize)


def setup(rank, world_size, seed):
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '12355'
    dist.init_process_group("gloo", rank=rank, world_size=world_size)
    torch.manual_seed(seed)

def train_gamegan(gpu, opts):
    # Enable Intel optimizations instead of CUDA benchmarking
    if device_manager.xpu_available:
        # Intel XPU optimizations for Arc 140V
        torch.backends.mkldnn.enabled = True
    else:
        # Intel CPU optimizations
        torch.backends.mkldnn.enabled = True

    normalize = True
    opts = copy.deepcopy(opts)
    start_epoch = 0
    opts.img_size = (opts.img_size, opts.img_size)
    warm_up = opts.warm_up
    opts.gpu = gpu
    opts.num_data_types = len(opts.data.split('-'))

    load_weights = False
    # load model
    if opts.saved_model is not None and opts.saved_model != '':
        gpu = opts.gpu
        log_dir = opts.log_dir

        saved_model = torch.load(opts.saved_model, map_location='cpu')
        saved_optim = torch.load(opts.saved_optim, map_location='cpu')
        opts = saved_model['opts']
        opts.gpu = gpu
        opts.log_dir = log_dir
        warm_up = opts.warm_up
        start_epoch = saved_model['epoch']
        load_weights = True

    if opts.num_gpu > 1:
        # Use Intel XPU distributed training if available, otherwise CPU
        backend = 'ccl' if device_manager.xpu_available else 'gloo'
        dist.init_process_group(
            backend=backend,
            init_method='env://',
            world_size=opts.num_gpu,
            rank=gpu
        )

    torch.manual_seed(opts.seed)
    # Set Intel device instead of CUDA
    set_device(gpu)

    # create model
    netG, netD = utils.build_models(opts)
    
    # Apply Intel-specific optimizations
    device = get_intel_device(gpu)
    
    # Optimize models with Intel Extension for PyTorch
    netG = optimize_for_intel(netG, dtype=torch.float16, device_id=gpu)
    netD = optimize_for_intel(netD, dtype=torch.float16, device_id=gpu)
    
    # choose optimizer
    optD = utils.choose_optimizer(netD, opts, opts.lrD)
    keyword = 'graphic'
    optG_temporal = utils.choose_optimizer(netG, opts, opts.lrG_temporal, exclude=keyword,
                                               model_name='optG_temporal')
    optG_graphic = utils.choose_optimizer(netG, opts, opts.lrG_graphic, include=keyword, model_name='optG_graphic')
    
    if load_weights:
        utils.load_my_state_dict(netG, saved_model['netG'])
        utils.load_my_state_dict(netD, saved_model['netD'])
        optG_temporal.load_state_dict(saved_optim['optG_temporal'])
        optG_graphic.load_state_dict(saved_optim['optG_graphic'])
        optD.load_state_dict(saved_optim['optD'])
        del saved_model, saved_optim

    if opts.num_gpu > 1:
        if device_manager.xpu_available:
            # Intel XPU distributed data parallel
            netG = nn.parallel.DistributedDataParallel(netG, device_ids=[gpu], find_unused_parameters=True)
            netD = nn.parallel.DistributedDataParallel(netD, device_ids=[gpu], find_unused_parameters=True)
        else:
            # CPU distributed data parallel
            netG = nn.parallel.DistributedDataParallel(netG, find_unused_parameters=True)
            netD = nn.parallel.DistributedDataParallel(netD, find_unused_parameters=True)


    # dataset ---
    print('setting up dataset')

    if opts.num_gpu > 1:
        train_dataset = dataloader.get_custom_dataset(opts, set_type=0, getLoader=False)
        val_dataset = dataloader.get_custom_dataset(opts, set_type=1, getLoader=False)
        train_sampler = torch.utils.data.distributed.DistributedSampler(
            train_dataset,
            num_replicas=opts.num_gpu,
            shuffle=True,
            rank=gpu
        )
        train_loader = torch.utils.data.DataLoader(
            dataset=train_dataset,
            batch_size=opts.bs,
            shuffle=False,
            num_workers=5,
            pin_memory=True,
            sampler=train_sampler,
            drop_last=True)
        val_sampler = torch.utils.data.distributed.DistributedSampler(
            val_dataset,
            num_replicas=opts.num_gpu,
            shuffle=False,
            rank=gpu
        )
        val_loader = torch.utils.data.DataLoader(
            dataset=val_dataset,
            batch_size=opts.bs,
            shuffle=False,
            num_workers=5,
            pin_memory=True,
            sampler=val_sampler,
            drop_last=True)
    else:
        train_loader = dataloader.get_custom_dataset(opts, set_type=0, getLoader=True)
        val_loader = dataloader.get_custom_dataset(opts, set_type=1, getLoader=True)

    # set up logger and trainer
    logging = True if gpu == 0 else False
    if logging:
        logger = SummaryWriter(opts.log_dir)

    zdist = utils.get_zdist('gaussian', opts.z, device=device)
    trainer = Trainer(opts,
                      netG, netD,
                      optG_temporal, optG_graphic, optD,
                      opts.gan_type, opts.reg_type, opts.LAMBDA, zdist)

    vis_num_row = 1
    if opts.num_steps > 29:
        vis_num_row = 3
    num_vis = 1
    cur_lr = opts.lr
    
    # Enable mixed precision training for Intel devices
    use_amp = device_manager.enable_mixed_precision()
    try:
        if device_manager.xpu_available:
            scaler = torch.amp.GradScaler('xpu') if use_amp else None
        else:
            scaler = torch.amp.GradScaler('cpu') if use_amp else None
    except Exception as e:
        print(f"Warning: Failed to create GradScaler: {e}")
        scaler = None
        use_amp = False
    
    for epoch in range(start_epoch, opts.nep):
        if epoch % opts.lr_decay_epoch  == 0 and epoch > 0 and cur_lr > opts.min_lr:
            cur_lr = cur_lr * 0.5
            utils.adjust_learning_rate(optG_temporal, cur_lr)
            utils.adjust_learning_rate(optG_graphic, cur_lr)
            utils.adjust_learning_rate(optD, cur_lr)
        print('Start epoch %d...' % epoch) if logging else None

        data_iters, train_len = [], 99999999999
        data_iters.append(iter(train_loader))
        if len(data_iters[-1]) < train_len:
            train_len = len(data_iters[-1])
        
        # Intel device memory optimization
        empty_cache()

        log_iter = max(1,int(train_len // 10))
        write_d = 0

        for step in range(train_len):
            it = epoch * train_len + step

            # prepare data
            sample = None
            states, actions, neg_actions = utils.get_data(data_iters, opts)

            # Use mixed precision if available
            autocast_context = device_manager.get_autocast_context()
            
            # Generators updates
            start = time.time()
            try:
                with autocast_context:
                    gloss_dict, gloss, gout, grads, dout_fake = \
                        trainer.generator_trainstep(states, actions, warm_up=warm_up, epoch=epoch)
                
                if scaler and use_amp:
                    scaler.scale(gloss).backward()
                    scaler.step(optG_temporal)
                    scaler.step(optG_graphic)
                    scaler.update()
                else:
                    gloss.backward()
                    optG_temporal.step()
                    optG_graphic.step()
            except Exception as e:
                print(f"Warning: Training step failed: {e}")
                continue
                
            gtime = time.time() - start

            # Discriminator updates
            if ((it + 1) % opts.Diters) == 0 and opts.gan_loss:
                start = time.time()
                with autocast_context:
                    dloss_dict = trainer.discriminator_trainstep(states, actions,
                                                                neg_actions, warm_up=warm_up, gout=gout, dout_fake=dout_fake,
                                                                epoch=epoch, step=step)
                dtime = time.time() - start

            # Synchronize Intel device operations
            synchronize()

            # Log
            if logging:
                with torch.no_grad():
                    if step == 0:
                        utils.plot_grad({'netG': trainer.netG, 'netD': trainer.netD}, logger, it)

                    loss_str = 'Generator [epoch %d, step %d / %d] ' % (epoch, step, train_len)
                    for k, v in gloss_dict.items():
                        if not (type(v) is float):
                            if (step % log_iter) == 0:
                                logger.add_scalar('losses/' + k, v.data.item(), it)
                            loss_str += k + ': ' + str(v.data.item()) + ', '
                    print(loss_str)
                    print('netG update:%f' % (gtime))

                if (step % log_iter) == 0:
                    # logging visualization
                    utils.draw_output(gout, states, warm_up, opts, vutils, vis_num_row, normalize, logger,
                                      it,
                                      num_vis, tag='trn_images')

                if ((it + 1) % opts.Diters) == 0 and opts.gan_loss:
                    loss_str = 'Discriminator [epoch %d, step %d / %d] ' % (epoch, step, train_len)
                    for k, v in dloss_dict.items():
                        if not (type(v) is float):
                            if (step % log_iter) == 0:
                                logger.add_scalar('losses/' + k, v.data.item(), it)
                            loss_str += k + ': ' + str(v.data.item()) + ', '
                    print(loss_str)
                    print('netD update:%f' % (dtime))

        # Intel device memory optimization after each epoch
        empty_cache()

        # save model
        if epoch % opts.save_epoch == 0 and logging:
            utils.save_model('%s/model_epoch_%04d.pth' % (opts.log_dir, epoch), epoch, netG, netD, opts)
            utils.save_optim('%s/optim_epoch_%04d.pth' % (opts.log_dir, epoch), epoch, optG_temporal, optG_graphic, optD)

if __name__ == '__main__':
    parser = config.init_parser()
    opts, unknown = parser.parse_known_args()
    print(opts)

    if opts.num_gpu > 1:
        mp.spawn(train_gamegan, nprocs=opts.num_gpu, args=(opts,))
    else:
        train_gamegan(0, opts)
