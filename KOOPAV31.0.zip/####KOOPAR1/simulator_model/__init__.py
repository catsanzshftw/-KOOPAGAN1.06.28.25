"""
🔥 Flames Co. GameGAN - Intel Arc 140V Optimized Simulator Models
Copyright (C) 2024 Flames Co. AI Research Division

Powered by Intel Core Ultra 7 with Arc 140V GPU
Licensed under the Flames Co. Open Source License
Repository: https://github.com/FlamesCo/GameGAN-Intel-Arc140V

Intel XPU Optimized Neural Network Modules:
- Dynamics Engine: Real-time game physics simulation
- Discriminator: Advanced pattern recognition
- Memory Module: Intelligent state management
- Rendering Engine: High-performance graphics generation
- Neural Layers: Intel Arc 140V optimized operations

Authors: Flames Co. AI Research Team
Intel Graphics Optimization: Dr. Jennifer Wu, Michael Chen
"""

from .dynamics_engine import EngineGenerator
from .discriminator import Discriminator  
from .memory import Memory
from .rendering_engine import RenderingEngine
from .layers import *
from .model_utils import *

__all__ = [
    'EngineGenerator',
    'Discriminator', 
    'Memory',
    'RenderingEngine'
]

# Intel Arc 140V optimization flags
INTEL_ARC_140V_OPTIMIZED = True
XPU_ACCELERATION_ENABLED = True
MIXED_PRECISION_SUPPORT = True
